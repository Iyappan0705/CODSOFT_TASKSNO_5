const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();
(async () => {
  const hash = (p) => bcrypt.hashSync(p, 10);
  await prisma.user.upsert({ where: { email: 'admin@fleetflow.com' }, update: {}, create: { name: 'Admin', email: 'admin@fleetflow.com', password: hash('admin123'), role: 'ADMIN' } });
  await prisma.user.upsert({ where: { email: 'driver@fleetflow.com' }, update: {}, create: { name: 'Ravi Driver', email: 'driver@fleetflow.com', password: hash('driver123'), role: 'DRIVER' } });
  await prisma.vehicle.upsert({ where: { plate: 'TN58AB1234' }, update: {}, create: { plate: 'TN58AB1234', model: 'Tata Ace' } });
  if (!(await prisma.warehouse.findFirst())) await prisma.warehouse.create({ data: { name: 'Madurai Hub', address: 'Madurai, Tamil Nadu' } });
  await prisma.shipment.upsert({ where: { trackingId: 'FF-1001' }, update: {}, create: { trackingId: 'FF-1001', customerName: 'Kumar Stores', origin: 'Madurai', destination: 'Chennai' } });
  console.log('Seed done');
  process.exit(0);
})();
