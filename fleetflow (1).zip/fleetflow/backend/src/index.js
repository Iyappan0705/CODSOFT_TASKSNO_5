require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const Redis = require('ioredis');
const { PrismaClient } = require('@prisma/client');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();
const redis = new Redis(process.env.REDIS_URL);
const app = express();
app.use(cors());
app.use(express.json());
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// WebSocket rooms: "admin" (all updates), "track:<trackingId>" (one customer)
io.on('connection', (s) => s.on('join', (room) => s.join(room)));

const auth = (roles) => (req, res, next) => {
  try {
    const token = (req.headers.authorization || '').split(' ')[1];
    const u = jwt.verify(token, process.env.JWT_SECRET);
    if (roles && !roles.includes(u.role)) return res.status(403).json({ error: 'Forbidden' });
    req.user = u;
    next();
  } catch {
    res.status(401).json({ error: 'Unauthorized' });
  }
};
const h = (fn) => (req, res) => fn(req, res).catch((e) => res.status(500).json({ error: e.message }));
const include = { driver: { select: { id: true, name: true } }, vehicle: true, warehouse: true };

// ---------- Auth ----------
app.post('/api/auth/login', h(async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !bcrypt.compareSync(password, user.password)) return res.status(400).json({ error: 'Invalid email or password' });
  const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, process.env.JWT_SECRET, { expiresIn: '1d' });
  res.json({ token, role: user.role, name: user.name });
}));

app.post('/api/auth/register', h(async (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'Name, email and password are required' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
  if (await prisma.user.findUnique({ where: { email } })) return res.status(400).json({ error: 'Email already registered' });
  const user = await prisma.user.create({ data: { name, email, password: bcrypt.hashSync(password, 10), role: role === 'ADMIN' ? 'ADMIN' : 'DRIVER' } });
  const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, process.env.JWT_SECRET, { expiresIn: '1d' });
  res.json({ token, role: user.role, name: user.name });
}));

// ---------- Master data ----------
app.get('/api/drivers', auth(['ADMIN']), h(async (_q, res) => res.json(await prisma.user.findMany({ where: { role: 'DRIVER' }, select: { id: true, name: true } }))));
app.get('/api/vehicles', auth(['ADMIN']), h(async (_q, res) => res.json(await prisma.vehicle.findMany())));
app.post('/api/vehicles', auth(['ADMIN']), h(async (req, res) => res.json(await prisma.vehicle.create({ data: req.body }))));
app.get('/api/warehouses', auth(['ADMIN']), h(async (_q, res) => res.json(await prisma.warehouse.findMany())));
app.post('/api/warehouses', auth(['ADMIN']), h(async (req, res) => res.json(await prisma.warehouse.create({ data: req.body }))));

// ---------- Shipments ----------
app.get('/api/shipments', auth(), h(async (req, res) => {
  const where = req.user.role === 'DRIVER' ? { driverId: req.user.id } : {};
  res.json(await prisma.shipment.findMany({ where, include, orderBy: { createdAt: 'desc' } }));
}));

app.post('/api/shipments', auth(['ADMIN']), h(async (req, res) => {
  const { customerName, origin, destination, warehouseId } = req.body;
  const trackingId = 'FF-' + Math.floor(1000 + Math.random() * 9000) + Date.now().toString().slice(-3);
  res.json(await prisma.shipment.create({ data: { trackingId, customerName, origin, destination, warehouseId: warehouseId ? +warehouseId : null }, include }));
}));

app.patch('/api/shipments/:id/assign', auth(['ADMIN']), h(async (req, res) => {
  const { driverId, vehicleId } = req.body;
  const s = await prisma.shipment.update({ where: { id: +req.params.id }, data: { driverId: +driverId, vehicleId: vehicleId ? +vehicleId : null, status: 'ASSIGNED' }, include });
  io.to('admin').emit('status', s);
  res.json(s);
}));

app.patch('/api/shipments/:id/status', auth(['DRIVER', 'ADMIN']), h(async (req, res) => {
  const existing = await prisma.shipment.findUnique({ where: { id: +req.params.id } });
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (req.user.role === 'DRIVER' && existing.driverId !== req.user.id) return res.status(403).json({ error: 'Not your shipment' });
  const { status } = req.body;
  const s = await prisma.shipment.update({ where: { id: existing.id }, data: { status, deliveredAt: status === 'DELIVERED' ? new Date() : null }, include });
  io.to('admin').emit('status', s);
  io.to('track:' + s.trackingId).emit('status', { status: s.status });
  res.json(s);
}));

// ---------- Live location (Redis + WebSocket) ----------
app.post('/api/location', auth(['DRIVER']), h(async (req, res) => {
  const { lat, lng } = req.body;
  const loc = { driverId: req.user.id, name: req.user.name, lat, lng, at: Date.now() };
  await redis.set('loc:' + req.user.id, JSON.stringify(loc), 'EX', 600);
  io.to('admin').emit('location', loc);
  const active = await prisma.shipment.findMany({ where: { driverId: req.user.id, status: { in: ['PICKED_UP', 'IN_TRANSIT'] } }, select: { trackingId: true } });
  active.forEach((s) => io.to('track:' + s.trackingId).emit('location', loc));
  res.json({ ok: true });
}));

// ---------- Public tracking ----------
app.get('/api/track/:trackingId', h(async (req, res) => {
  const s = await prisma.shipment.findUnique({ where: { trackingId: req.params.trackingId }, include });
  if (!s) return res.status(404).json({ error: 'Tracking ID not found' });
  const raw = s.driverId ? await redis.get('loc:' + s.driverId) : null;
  res.json({ trackingId: s.trackingId, status: s.status, origin: s.origin, destination: s.destination, driver: s.driver?.name, location: raw ? JSON.parse(raw) : null });
}));

// ---------- Analytics ----------
app.get('/api/stats', auth(['ADMIN']), h(async (_q, res) => {
  const byStatus = await prisma.shipment.groupBy({ by: ['status'], _count: true });
  const perDriver = await prisma.shipment.groupBy({ by: ['driverId'], where: { status: 'DELIVERED' }, _count: true });
  const total = await prisma.shipment.count();
  const delivered = byStatus.find((x) => x.status === 'DELIVERED')?._count || 0;
  res.json({ total, delivered, deliveryRate: total ? Math.round((delivered / total) * 100) : 0, byStatus, perDriver });
}));

server.listen(process.env.PORT || 4000, () => console.log('FleetFlow API on port ' + (process.env.PORT || 4000)));
