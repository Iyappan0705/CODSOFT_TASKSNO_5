# FleetFlow – Logistics & Fleet Management Platform

Stack: Next.js · Node.js (Express) · PostgreSQL (Prisma) · Redis · Socket.IO (WebSockets)

## Setup (VS Code terminal)
1. Install Node.js 18+ and Docker Desktop.
2. Start database + Redis:      `docker compose up -d`
3. Backend:
   ```
   cd backend
   npm install
   npx prisma migrate dev --name init
   npm run seed
   npm run dev          # http://localhost:4000
   ```
4. Frontend (new terminal):
   ```
   cd frontend
   npm install
   npm run dev          # http://localhost:3000
   ```
5. Open http://localhost:3000 → Register (as Admin or Driver) → Login with your own email/password.
   Customer tracking: http://localhost:3000/track  (tracking ID FF-1001)

## Demo flow
Admin creates shipment → assigns driver + vehicle → Driver logs in (another browser/incognito),
clicks "Start sharing location" and updates status → Admin sees live location, customer sees map + status.
