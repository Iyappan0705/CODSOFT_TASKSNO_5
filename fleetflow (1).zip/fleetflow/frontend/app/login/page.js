'use client';
import { useState } from 'react';
import { api } from '../../lib/api';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setErr(''); setBusy(true);
    try {
      const d = await api('/auth/login', { method: 'POST', body: { email, password } });
      localStorage.setItem('token', d.token);
      localStorage.setItem('name', d.name);
      localStorage.setItem('role', d.role);
      window.location.href = d.role === 'ADMIN' ? '/admin' : '/driver';
    } catch (e) { setErr(e.message); setBusy(false); }
  }
  return (
    <div className="auth-wrap">
      <form className="auth-card" onSubmit={submit}>
        <h2>Welcome back</h2>
        <p className="sub">Login to your FleetFlow account</p>
        <label>Email</label>
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
        <label>Password</label>
        <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Your password" />
        <button className="btn" disabled={busy}>{busy ? 'Logging in...' : 'Login'}</button>
        {err && <div className="err">{err}</div>}
        <div className="alt">New here? <a href="/register">Create an account</a></div>
      </form>
    </div>
  );
}
