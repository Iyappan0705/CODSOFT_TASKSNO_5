'use client';
import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';

export default function Nav() {
  const [name, setName] = useState(null);
  const [role, setRole] = useState(null);
  const path = usePathname();
  useEffect(() => {
    setName(localStorage.getItem('token') ? localStorage.getItem('name') : null);
    setRole(localStorage.getItem('role'));
  }, [path]);

  function logout() {
    localStorage.clear();
    window.location.href = '/';
  }
  return (
    <nav className="nav">
      <a href="/" className="logo">🚚 FleetFlow</a>
      <div className="nav-links">
        <a href="/track">Track shipment</a>
        {name ? (
          <>
            <a href={role === 'ADMIN' ? '/admin' : '/driver'}>Dashboard</a>
            <span style={{ color: '#5b6b82' }}>Hi, {name}</span>
            <button className="btn btn-outline" onClick={logout}>Logout</button>
          </>
        ) : (
          <>
            <a href="/login">Login</a>
            <a href="/register" className="btn">Get started</a>
          </>
        )}
      </div>
    </nav>
  );
}
