import './globals.css';
import Nav from './components/Nav';

export const metadata = { title: 'FleetFlow – Logistics & Fleet Management' };
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Nav />
        <main>{children}</main>
      </body>
    </html>
  );
}
