'use client';
import { useState } from 'react';
import { api } from '../../lib/api';

export default function Register() {
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'DRIVER' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setErr(''); setBusy(true);
    try {
      const d = await api('/auth/register', { method: 'POST', body: f });
      localStorage.setItem('token', d.token);
      localStorage.setItem('name', d.name);
      localStorage.setItem('role', d.role);
      window.location.href = d.role === 'ADMIN' ? '/admin' : '/driver';
    } catch (e) { setErr(e.message); setBusy(false); }
  }
  return (
    <div className="auth-wrap">
      <form className="auth-card" onSubmit={submit}>
        <h2>Create account</h2>
        <p className="sub">Join FleetFlow as an admin or a driver</p>
        <label>Full name</label>
        <input required value={f.name} onChange={set('name')} placeholder="Your name" />
        <label>Email</label>
        <input type="email" required value={f.email} onChange={set('email')} placeholder="you@example.com" />
        <label>Password</label>
        <input type="password" required minLength={6} value={f.password} onChange={set('password')} placeholder="At least 6 characters" />
        <label>I am a</label>
        <select value={f.role} onChange={set('role')}>
          <option value="DRIVER">Driver</option>
          <option value="ADMIN">Admin</option>
        </select>
        <button className="btn" disabled={busy}>{busy ? 'Creating...' : 'Register'}</button>
        {err && <div className="err">{err}</div>}
        <div className="alt">Already have an account? <a href="/login">Login</a></div>
      </form>
    </div>
  );
}
