'use client';
import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { api, API } from '../../lib/api';

export default function Admin() {
  const [shipments, setShipments] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [stats, setStats] = useState(null);
  const [live, setLive] = useState({});
  const [form, setForm] = useState({ customerName: '', origin: '', destination: '' });
  const [pick, setPick] = useState({});

  async function load() {
    setShipments(await api('/shipments'));
    setDrivers(await api('/drivers'));
    setVehicles(await api('/vehicles'));
    setStats(await api('/stats'));
  }
  useEffect(() => {
    load().catch(() => (window.location.href = '/login'));
    const s = io(API);
    s.emit('join', 'admin');
    s.on('location', (l) => setLive((p) => ({ ...p, [l.driverId]: l })));
    s.on('status', () => load());
    return () => s.disconnect();
  }, []);

  async function create() {
    await api('/shipments', { method: 'POST', body: form });
    setForm({ customerName: '', origin: '', destination: '' });
    load();
  }
  async function assign(id) {
    const p = pick[id] || {};
    if (!p.driverId) return alert('Select a driver');
    await api(`/shipments/${id}/assign`, { method: 'PATCH', body: p });
    load();
  }

  return (
    <div>
      <h2>Admin Dashboard</h2>
      {stats && (
        <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
          <Card t="Total shipments" v={stats.total} />
          <Card t="Delivered" v={stats.delivered} />
          <Card t="Delivery rate" v={stats.deliveryRate + '%'} />
          <Card t="Drivers online" v={Object.keys(live).length} />
        </div>
      )}

      <Box title="New shipment">
        {['customerName', 'origin', 'destination'].map((k) => (
          <input key={k} style={inp} placeholder={k} value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
        ))}
        <button style={btn} onClick={create}>Create</button>
      </Box>

      <Box title="Shipments">
        <table width="100%" cellPadding={6}>
          <thead><tr align="left"><th>Tracking</th><th>Customer</th><th>Route</th><th>Status</th><th>Driver / Vehicle</th></tr></thead>
          <tbody>
            {shipments.map((s) => (
              <tr key={s.id} style={{ borderTop: '1px solid #e3e8f0' }}>
                <td>{s.trackingId}</td><td>{s.customerName}</td><td>{s.origin} → {s.destination}</td><td>{s.status}</td>
                <td>
                  {s.status === 'PENDING' ? (
                    <>
                      <select onChange={(e) => setPick({ ...pick, [s.id]: { ...pick[s.id], driverId: e.target.value } })}>
                        <option value="">driver</option>{drivers.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
                      </select>{' '}
                      <select onChange={(e) => setPick({ ...pick, [s.id]: { ...pick[s.id], vehicleId: e.target.value } })}>
                        <option value="">vehicle</option>{vehicles.map((v) => <option key={v.id} value={v.id}>{v.plate}</option>)}
                      </select>{' '}
                      <button onClick={() => assign(s.id)}>Assign</button>
                    </>
                  ) : `${s.driver?.name || '-'} / ${s.vehicle?.plate || '-'}`}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Box>

      <Box title="Live driver locations">
        {Object.values(live).length === 0 && <p>No driver is sharing location yet.</p>}
        {Object.values(live).map((l) => (
          <p key={l.driverId}>📍 {l.name}: {l.lat.toFixed(5)}, {l.lng.toFixed(5)} ({new Date(l.at).toLocaleTimeString()})</p>
        ))}
      </Box>
    </div>
  );
}
const Card = ({ t, v }) => <div style={{ background: '#fff', padding: 16, borderRadius: 10, flex: 1 }}><small>{t}</small><h2 style={{ margin: 0 }}>{v}</h2></div>;
const Box = ({ title, children }) => <div style={{ background: '#fff', padding: 16, borderRadius: 10, marginBottom: 16 }}><h3 style={{ marginTop: 0 }}>{title}</h3>{children}</div>;
const inp = { padding: 8, marginRight: 8 };
const btn = { padding: '8px 16px', background: '#0b3a7a', color: '#fff', border: 0, borderRadius: 6, cursor: 'pointer' };
