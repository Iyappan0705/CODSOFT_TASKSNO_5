'use client';
import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { api, API } from '../../lib/api';

export default function Track() {
  const [id, setId] = useState('FF-1001');
  const [data, setData] = useState(null);
  const [err, setErr] = useState('');

  async function search() {
    try { setErr(''); setData(await api('/track/' + id)); } catch (e) { setErr(e.message); setData(null); }
  }
  useEffect(() => {
    if (!data) return;
    const s = io(API);
    s.emit('join', 'track:' + data.trackingId);
    s.on('location', (l) => setData((d) => ({ ...d, location: l })));
    s.on('status', (u) => setData((d) => ({ ...d, status: u.status })));
    return () => s.disconnect();
  }, [data?.trackingId]);

  const loc = data?.location;
  const d = 0.01;
  return (
    <div>
      <h2>Track your shipment</h2>
      <input value={id} onChange={(e) => setId(e.target.value)} style={{ padding: 8 }} />{' '}
      <button onClick={search} style={{ padding: '8px 16px' }}>Track</button>
      {err && <p style={{ color: 'crimson' }}>{err}</p>}
      {data && (
        <div style={{ background: '#fff', padding: 16, borderRadius: 10, marginTop: 16 }}>
          <p><b>{data.trackingId}</b> · {data.origin} → {data.destination}</p>
          <p>Status: <b>{data.status}</b> · Driver: {data.driver || 'not assigned yet'}</p>
          {loc ? (
            <iframe width="100%" height="350" style={{ border: 0 }}
              src={`https://www.openstreetmap.org/export/embed.html?bbox=${loc.lng - d},${loc.lat - d},${loc.lng + d},${loc.lat + d}&marker=${loc.lat},${loc.lng}`} />
          ) : <p>Driver location not available yet.</p>}
        </div>
      )}
    </div>
  );
}
