export default function Home() {
  const features = [
    ['📦', 'Shipment management', 'Create shipments, assign drivers and vehicles, and follow every delivery from pending to delivered.'],
    ['📍', 'Live GPS tracking', 'Driver locations stream in real time using WebSockets, so you always know where a delivery is.'],
    ['📱', 'Driver mobile view', 'Drivers see only their assigned deliveries and update status with one tap from their phone.'],
    ['🏭', 'Warehouse & fleet', 'Keep warehouses, vehicles and drivers organised in one place.'],
    ['📊', 'Performance analytics', 'Delivery rate, shipments by status and deliveries per driver at a glance.'],
    ['🔐', 'Secure role-based access', 'Separate admin and driver logins protected with JWT authentication.'],
  ];
  return (
    <div className="landing">
      <section className="hero">
        <h1>Complete visibility over<br />every delivery</h1>
        <p>FleetFlow is a real-time logistics platform to manage shipments, drivers, vehicles, routes and warehouses, all from one dashboard.</p>
        <a href="/register" className="btn">Create account</a>
        <a href="/login" className="btn btn-outline">Login</a>
      </section>

      <section className="stats">
        <div><b>Real-time</b><span>driver tracking</span></div>
        <div><b>3 roles</b><span>admin · driver · customer</span></div>
        <div><b>1 dashboard</b><span>for the whole fleet</span></div>
      </section>

      <section className="section">
        <h2>Everything your logistics team needs</h2>
        <p className="sub">Built for admins, drivers and customers.</p>
        <div className="grid">
          {features.map(([ic, t, d]) => (
            <div className="card" key={t}><div className="ic">{ic}</div><h3>{t}</h3><p>{d}</p></div>
          ))}
        </div>
      </section>

      <section className="section" style={{ paddingTop: 0 }}>
        <h2>How it works</h2>
        <p className="sub">From order to doorstep in three steps.</p>
        <div className="grid">
          <div className="step card"><div className="num">1</div><h3>Admin assigns</h3><p>Create a shipment and assign a driver and vehicle.</p></div>
          <div className="step card"><div className="num">2</div><h3>Driver delivers</h3><p>Driver shares location and updates status on the road.</p></div>
          <div className="step card"><div className="num">3</div><h3>Customer tracks</h3><p>Customer enters the tracking ID and sees the live map.</p></div>
        </div>
      </section>

      <section className="cta">
        <h2 style={{ marginTop: 0, color: '#0b2a5b' }}>Have a tracking ID?</h2>
        <p style={{ color: '#5b6b82' }}>Check where your shipment is right now.</p>
        <a href="/track" className="btn">Track my shipment</a>
      </section>

      <footer className="footer">© 2026 FleetFlow · Logistics & Fleet Management Platform</footer>
    </div>
  );
}
