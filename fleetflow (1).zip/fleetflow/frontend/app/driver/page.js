'use client';
import { useEffect, useRef, useState } from 'react';
import { api, NEXT_STATUS } from '../../lib/api';

export default function Driver() {
  const [shipments, setShipments] = useState([]);
  const [sharing, setSharing] = useState(false);
  const watchId = useRef(null);
  const lastSent = useRef(0);

  const load = async () => setShipments(await api('/shipments'));
  useEffect(() => { load().catch(() => (window.location.href = '/login')); }, []);

  async function advance(s) {
    await api(`/shipments/${s.id}/status`, { method: 'PATCH', body: { status: NEXT_STATUS[s.status] } });
    load();
  }
  function toggleShare() {
    if (sharing) { navigator.geolocation.clearWatch(watchId.current); return setSharing(false); }
    watchId.current = navigator.geolocation.watchPosition((p) => {
      if (Date.now() - lastSent.current < 3000) return; // send every 3 sec max
      lastSent.current = Date.now();
      api('/location', { method: 'POST', body: { lat: p.coords.latitude, lng: p.coords.longitude } });
    }, (e) => alert(e.message), { enableHighAccuracy: true });
    setSharing(true);
  }

  return (
    <div>
      <h2>My Deliveries</h2>
      <button onClick={toggleShare} style={{ padding: '10px 18px', background: sharing ? '#c0392b' : '#1e8449', color: '#fff', border: 0, borderRadius: 6 }}>
        {sharing ? 'Stop sharing location' : 'Start sharing location'}
      </button>
      {shipments.map((s) => (
        <div key={s.id} style={{ background: '#fff', padding: 16, borderRadius: 10, marginTop: 14 }}>
          <b>{s.trackingId}</b> — {s.customerName}<br />
          {s.origin} → {s.destination}<br />
          Status: <b>{s.status}</b>{' '}
          {NEXT_STATUS[s.status] && <button onClick={() => advance(s)}>Mark {NEXT_STATUS[s.status]}</button>}
        </div>
      ))}
      {shipments.length === 0 && <p>No deliveries assigned.</p>}
    </div>
  );
}
